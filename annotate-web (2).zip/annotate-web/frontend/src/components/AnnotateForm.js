import React, { useState } from 'react';
import TimingPicker from './TimingPicker';

const AnnotateForm = () => {
    const [name, setName] = useState('');
    const [deviceIds, setDeviceIds] = useState([]);
    const [timestamp, setTimestamp] = useState('NOW');
    const [conditions, setConditions] = useState([]);
    const [activities, setActivities] = useState([]);
    const [people, setPeople] = useState(3);
    const [otherFactors, setOtherFactors] = useState({});

    const handleDeviceIdInput = (e) => {
        if (e.key === 'Enter' || e.key === ',' || e.key === ' ') {
            const value = e.target.value.trim();
            if (value && !deviceIds.includes(value)) {
                setDeviceIds([...deviceIds, value]);
            }
            e.target.value = '';
        }
    };

    const handleConditionToggle = (condition) => {
        setConditions((prev) =>
            prev.includes(condition)
                ? prev.filter((c) => c !== condition)
                : [...prev, condition]
        );
    };

    const handleActivityAdd = (activity) => {
        if (activity && !activities.includes(activity)) {
            setActivities([...activities, activity]);
        }
    };

    const handleSave = async () => {
        const annotation = {
            name,
            deviceIds,
            timestamp,
            conditions,
            activities,
            factors: {
                people,
                otherFactors,
            },
        };

        try {
            const response = await fetch('http://localhost:5000/api/annotations/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(annotation),
            });
            if (response.ok) {
                alert('Annotation saved successfully!');
                clearForm();
            } else {
                alert('Failed to save annotation.');
            }
        } catch (error) {
            console.error(error);
            alert('An error occurred.');
        }
    };

    const clearForm = () => {
        setName('');
        setDeviceIds([]);
        setTimestamp('NOW');
        setConditions([]);
        setActivities([]);
        setPeople(3);
        setOtherFactors({});
    };

    return (
        <div className="container">
            <h1>Annotate</h1>
            <div className="section">
                <input
                    type="text"
                    placeholder="NAME"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Device ID"
                    onKeyDown={handleDeviceIdInput}
                />
                <div className="tag-group">
                    {deviceIds.map((id, index) => (
                        <div key={index} className="tag">
                            {id}
                        </div>
                    ))}
                </div>
            </div>
            <TimingPicker timestamp={timestamp} setTimestamp={setTimestamp} />
            <div className="section">
                <h2>Conditions</h2>
                <div className="tag-group">
                    {['AC', 'Fan', 'Window'].map((condition) => (
                        <div
                            key={condition}
                            className={`tag ${conditions.includes(condition) ? 'active' : ''}`}
                            onClick={() => handleConditionToggle(condition)}
                        >
                            {condition}
                        </div>
                    ))}
                </div>
            </div>
            <div className="section">
                <h2>Activities</h2>
                <select
                    onChange={(e) => handleActivityAdd(e.target.value)}
                    defaultValue="Select Activity"
                >
                    <option disabled>Select Activity</option>
                    <option>Smoking Cigarette</option>
                    <option>Other Activity</option>
                </select>
                <div className="tag-group">
                    {activities.map((activity, index) => (
                        <div key={index} className="tag">
                            {activity}
                        </div>
                    ))}
                </div>
            </div>
            <div className="section">
                <h2>Other Factors</h2>
                <div className="number-group">
                    <label>#People</label>
                    <input
                        type="number"
                        value={people}
                        onChange={(e) => setPeople(parseInt(e.target.value, 10))}
                    />
                </div>
            </div>
            <div className="button-group">
                <button className="button" onClick={handleSave}>
                    SAVE
                </button>
                <button className="button" onClick={clearForm}>
                    CLEAR FORM
                </button>
            </div>
        </div>
    );
};

export default AnnotateForm;
