const mongoose = require('mongoose');

const annotationSchema = mongoose.Schema({
    name: String,
    deviceIds: [String],
    timestamp: String,
    conditions: [String],
    activities: [String],
    factors: {
        people: Number,
        otherFactors: Object,
    },
});

module.exports = mongoose.model('Annotation', annotationSchema);
