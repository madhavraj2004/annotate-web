const express = require('express');
const Annotation = require('../models/Annotation');
const router = express.Router();

router.post('/save', async (req, res) => {
    try {
        const annotation = new Annotation(req.body);
        await annotation.save();
        res.status(201).json({ message: 'Annotation saved successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get('/annotations', async (req, res) => {
    try {
        const annotations = await Annotation.find();
        res.json(annotations);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
