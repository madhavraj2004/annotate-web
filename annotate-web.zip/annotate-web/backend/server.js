const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const bodyParser = require('body-parser');

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// In-memory data store (optional, you can replace it with a database)
let savedData = [];

// Route to save data
app.post('/api/save', (req, res) => {
    const { data } = req.body;

    if (data) {
        // Save data to in-memory store (replace with DB operation if needed)
        savedData.push(data);

        console.log('Data saved:', data);
        res.status(200).json({ message: 'Data saved successfully!' });
    } else {
        res.status(400).json({ error: 'No data provided' });
    }
});

// Route to fetch saved data
app.get('/api/data', (req, res) => {
    res.status(200).json(savedData);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
