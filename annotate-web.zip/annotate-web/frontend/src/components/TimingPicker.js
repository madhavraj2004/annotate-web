import React, { useState } from 'react';

const TimingPicker = ({ timestamp, setTimestamp }) => {
    const [customTimestamp, setCustomTimestamp] = useState('');

    const handleNowClick = () => {
        setTimestamp('NOW');
    };

    const handleCustomClick = () => {
        const selectedTimestamp = prompt('Enter custom timestamp (YYYY-MM-DD HH:mm):');
        if (selectedTimestamp) {
            setCustomTimestamp(selectedTimestamp);
            setTimestamp(selectedTimestamp);
        }
    };

    return (
        <div className="section">
            <h2>Timing</h2>
            <div className="button-group">
                <div
                    className={`button ${timestamp === 'NOW' ? 'active' : ''}`}
                    onClick={handleNowClick}
                >
                    NOW
                </div>
                <div
                    className={`button ${timestamp !== 'NOW' ? 'active' : ''}`}
                    onClick={handleCustomClick}
                >
                    Custom
                </div>
            </div>
        </div>
    );
};

export default TimingPicker;
