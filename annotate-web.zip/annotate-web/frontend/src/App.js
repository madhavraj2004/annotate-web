import React, { useState } from 'react';
import AnnotateForm from './components/AnnotateForm';
import './styles.css';

function App() {
    const [inputFieldValue, setInputFieldValue] = useState('');

    const handleSave = () => {
        if (inputFieldValue) {
            // Send data to backend
            fetch('/api/save', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ data: inputFieldValue }),
            })
                .then((response) => response.json())
                .then((data) => {
                    alert('Data saved successfully!');
                })
                .catch((error) => {
                    console.error('Error saving data:', error);
                    alert('Failed to save data.');
                });
        } else {
            alert('Please enter some data to save.');
        }
    };

    const handleClear = () => {
        setInputFieldValue('');
    };

    return (
        <div className="App">
            <AnnotateForm
                inputFieldValue={inputFieldValue}
                setInputFieldValue={setInputFieldValue}
            />
            <div className="button-group">
                <button id="saveButton" onClick={handleSave}>
                    Save
                </button>
                <button id="clearButton" onClick={handleClear}>
                    Clear
                </button>
            </div>
        </div>
    );
}

export default App;
